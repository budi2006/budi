#!/bin/sh

red='\033[1;31m'

green='\033[1;32m'

yellow='\033[1;33m'

blue='\033[1;34m'

purple='\033[1;35m'

cyan='\033[1;36m'

white='\033[1;37m'

ulang='y'
while [ $ulang = 'y' ]
do
  echo $green'1.buat password'
  echo $red '2.tempatkan BFzip ditempat locasi pengekstraan'
  echo $blue '0.batalkan'
  echo -n 'masukan pilihan: '
  read pil;
  if [ $pil = '1' ] || [ $pil = '01' ]:
  then
      echo $green 'tunggu bro'
      sleep 2
      echo 'script ini masih beta jadi ini gak bisa kembali harus memulai dari awal'
      sleep 5
      cd $HOME/beta_brute_force_zip
      touch password.txt
      nano password.txt
  elif [ $pil = '2' ] || [ $pil = '02' ]:
  then
      read -p 'masukan tempat file yang ingin dicrack : ' vex;
      cd $HOME/beta_brute_force_zip
      cp BFzip.py $vex
      mv password.txt $vex
      cd $vex
      ls
        echo -n 'mau buka command [Y/N]'
        read pil;
        if [ $pil = 'y' ] || [ $pil = 'Y' ]:
        then
            python2 BFzip.py
        else
            echo 'exiting'
            sleep 1
            echo $ulang
               fi
  elif [ $pil = '0' ] || [ $pil = '00' ]:
  then
      echo 'bye bye....'
      cd $HOME/beta_brute_force_zip
      sleep 2
      exit
  else
      echo 'Error WRONG input'
      echo $ulang
fi
done