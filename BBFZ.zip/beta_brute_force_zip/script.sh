red='\033[1;31m'

green='\033[1;32m'

yellow='\033[1;33m'

blue='\033[1;34m'

purple='\033[1;35m'

cyan='\033[1;36m'

white='\033[1;37m'


#variabel

echo $yellow "
===================================================
               WELCOME TO MYPROJECT
               PROJECT BETA VERSION
                     V0.12.5
MY NAME : BUDI
CODE BY : CH SNIPERELITETV
MY INSTAGRAM : @budibima06
GRUP : DUNIA HACKER DHI (DHI)
CONTACT : bb547943@gmail.com

THANK TO USE MY CODE
===================================================="


#variabel
ulang='y'
while [ $ulang = 'y' ]:
do
  echo $green '1.install bahan bahan untuk bisa digunakan'
  echo $red '2.langsung install tools'
  echo $cyan '0.exit'
  echo -n  'masukan pilihan : '
  read pil;
  if [ $pil = '1' ] || [ $pil = '01' ]:
  then
      echo $cyan 'tunggu bro ini tergantung dari koneksi lo'
      sleep 3
      apt upgrade && apt update
      pkg update && pkg upgrade
      pkg install figlet
      pkg install ncurses-utils
      pkg install mc
      pkg install python
      pkg install python2
      pkg install pip2
      pkg install pip
      pip install request
      pkg install ruby
      pkg install cowsay
  elif [ $pil = '2' ] || [ $pil = '02' ]:
  then
      cd semvak
      sh installerBFZ.sh
  elif [ $pil = '0' ] || [ $pil = '00' ]:
  then
      echo 'Bye Bye ......'
      sleep 2
      exit
  else
      echo 'ERROR:Wrong input'
      echo $ulang
fi
done